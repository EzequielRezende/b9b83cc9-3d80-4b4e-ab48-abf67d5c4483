package com.example.eunaservice;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        WebSettings webSettings = webView.getSettings();

        // Permitir a execução de JavaScript
        webSettings.setJavaScriptEnabled(true);

        // Permitir o armazenamento da Web
        webSettings.setDomStorageEnabled(true);

        // Configurar o WebView para abrir links internamente (não abrir no navegador padrão)
        webView.setWebViewClient(new WebViewClient());

        // Carregar o site fornecido
        webView.loadUrl("https://env-0281185.mircloud.host/");
    }

    // Garantir que os links sejam abertos no WebView em vez de no navegador padrão
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    // Adicionar esta parte para lidar com a execução de JavaScript explicitamente
    @Override
    public void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    public void onPause() {
        webView.onPause();
        super.onPause();
    }

    @Override
    public void onDestroy() {
        webView.destroy();
        super.onDestroy();
    }
}
